-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Апр 30 2020 г., 12:39
-- Версия сервера: 10.4.10-MariaDB
-- Версия PHP: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `photogallery`
--

-- --------------------------------------------------------

--
-- Структура таблицы `images`
--

DROP TABLE IF EXISTS `images`;
CREATE TABLE IF NOT EXISTS `images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  `size` int(11) NOT NULL,
  `seen` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `images`
--

INSERT INTO `images` (`id`, `name`, `path`, `size`, `seen`) VALUES
(1, 'img1.png', 'big_image.php?name=img1.png', 672, 6),
(2, 'img2.jpg', 'big_image.php?name=img2.jpg', 159, 2),
(3, 'img3.jpg', 'big_image.php?name=img3.jpg', 294, 2),
(4, 'img4.jpg', 'big_image.php?name=img4.jpg', 192, 2),
(5, 'img5.jpg', 'big_image.php?name=img5.jpg', 226, 2),
(6, 'img6.jpg', 'big_image.php?name=img6.jpg', 231, 2),
(7, 'img7.jpg', 'big_image.php?name=img7.jpg', 184, 4),
(8, 'img8.jpg', 'big_image.php?name=img8.jpg', 213, 2),
(9, 'img9.jpg', 'big_image.php?name=img9.jpg', 426, 2),
(10, 'img10.jpg', 'big_image.php?name=img10.jpg', 202, 2),
(11, 'img11.jpg', 'big_image.php?name=img11.jpg', 377, 2),
(12, 'img12.jpg', 'big_image.php?name=img12.jpg', 1690, 2),
(13, 'img13.jpg', 'big_image.php?name=img13.jpg', 305, 4),
(14, 'img14.jpg', 'big_image.php?name=img14.jpg', 350, 2),
(15, 'original.png', 'big_image.php?name=original.png', 289, 2);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
